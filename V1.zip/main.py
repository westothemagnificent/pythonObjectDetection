from cam import *

# Add HaarCascade
cam.addHarrCascade(
    HaarcascadeObject(
        "face",
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml",
        (50, 120, 255),
        lambda x, y, w, h: print(f"I see a face at: {(x, y, w, h)}"),
    )
)

# Detect blue in (BGR)
cam.addColoredObject(
    ColoredObject(
        "blue",
        (80, 0, 0),
        (200, 100, 100),
        200,
        (255, 100, 100),
        lambda x, y, w, h: print(f"I see a blue object at: {(x, y, w, h)}"),
    )
)

# add april tag (not need to detect april tag just needed to have a callback)

cam.addAprilTag(
    AprilTag(
        "cool marker",
        12,
        (255,60,80),
        lambda x,y,w,h: print(f"I see a cool marker at: {(x,y,w,h)}"),
    )
)

# cam.addShapeAndColoredObject(
#     ShapeAndColoredObject(
#         "cool object",
#         "coolFile.png",
#         0.5,
#         (50,200,40),
#         lambda x,y,w,h: print(f"I see a cool object at: {(x,y,w,h)}"),
#     )
# )

# simple photo taker
def tickTakePhoto():
    ret, frame = cap.read()
    if cv2.waitKey(1) & 0xFF == ord('p'):
        
        userInput = input("take photo? (Y/N): ")
        if(userInput == "Y"):
            userInput = input("name: ")
            cv2.imwrite(f"{userInput}.jpg", frame)
            print(f"Photo taken and saved as '{userInput}'.")



if not cap.isOpened():
    print("(!)-- Could not open camera.")
else:
    while True:
        
        # tick the cam to find objects added above
        cam.analyze()
        
        # tick photos
        tickTakePhoto()
        
        # see if "q" pressed if so exit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break


cap.release()
cv2.destroyAllWindows()