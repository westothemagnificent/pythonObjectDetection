import cv2
import numpy as np
from typing import Callable

if hasattr(cv2, 'aruco'):
    aruco = cv2.aruco
else:
    raise ImportError("Aruco module not found in cv2.")

arucoDict = aruco.getPredefinedDictionary(aruco.DICT_APRILTAG_36h11)
parameters = aruco.DetectorParameters()

detector = aruco.ArucoDetector(arucoDict, parameters)

class HaarcascadeObject:
    name : str
    fileDir : str
    color : tuple[int, int, int]
    cascade : cv2.CascadeClassifier
    
    callback : Callable[[int, int, int, int], None]
    
    def __init__(self, Name : str, FileDir : str, Color : tuple[int, int, int], Callback : Callable[[int, int, int, int], None]) -> None:
        self.name : str = Name
        self.fileDir : str = FileDir
        self.color : tuple[int, int, int] = Color
        self.cascade : cv2.CascadeClassifier = cv2.CascadeClassifier(self.fileDir)
        self.callback = Callback


class ColoredObject:
    name : str
    colorHigh : tuple[int, int, int]
    colorLow : tuple[int, int, int]
    threshold : float
    rectColor : tuple[int, int, int]
    
    callback : Callable[[int, int, int, int], None]
    
    def __init__(self, Name : str, ColorLow : tuple[int, int, int],  ColorHigh : tuple[int, int, int], Threshold : float, RectColor : tuple[int, int, int], Callback : Callable[[int, int, int, int], None]) -> None:
        self.name = Name
        self.colorHigh = ColorHigh
        self.colorLow = ColorLow
        self.rectColor = RectColor
        self.threshold = Threshold
        self.callback = Callback


class ShapeAndColoredObject:
    name : str
    color : tuple[int, int, int]
    threshold : float
    targetImage : np.ndarray
    
    callback : Callable[[int, int, int, int], None]
    
    def __init__(self, Name : str, TargetImageDir : str, Threshold : float, Color : tuple[int, int, int], Callback : Callable[[int, int, int, int], None]) -> None:
        self.name = Name
        self.threshold = Threshold
        self.targetImage = cv2.imread(TargetImageDir)
        self.color = Color
        self.callback = Callback

class AprilTag:
    name : str
    color : tuple[int, int, int]
    id : int
    
    callback : Callable[[int, int, int, int], None]
    
    def __init__(self, Name : str, Id : int, Color : tuple[int, int, int], Callback : Callable[[int, int, int, int], None]) -> None:
        self.name = Name
        self.color = Color
        self.id = Id
        self.callback = Callback


class Camera:
    
    harrCascades : list[HaarcascadeObject] = []
    coloredObjects : list[ColoredObject] = []
    shapeAndColoredObjects : list[ShapeAndColoredObject] = []
    aprilTags : list[AprilTag] = []
    
    def __init__(self) -> None:
        pass
    
    
    def detectHarrCascades(self, frame : np.ndarray) -> np.ndarray:

        for harr in self.harrCascades:
        
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            harrObject : list[tuple[int, int, int, int]] = harr.cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

            for (x, y, w, h) in harrObject:
                frame = cv2.rectangle(frame, (x, y), (x+w, y+h), harr.color, 2)
                
                harr.callback(x, y, w, h)
                
                
        return frame
    
    def detectColoredObjects(self, frame : np.ndarray) -> np.ndarray:
        
        for coloredObject in self.coloredObjects:
            
            mask : np.ndarray = cv2.inRange(frame, coloredObject.colorLow, coloredObject.colorHigh)

            result : np.ndarray = cv2.bitwise_and(frame, frame, mask=mask)
            
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
            for contour in contours:
                if cv2.contourArea(contour) > coloredObject.threshold: 
                    x, y, w, h = cv2.boundingRect(contour)
                    frame = cv2.rectangle(frame, (x, y), (x + w, y + h), coloredObject.rectColor, 2)
                    
                    coloredObject.callback(x, y, w, h)
    

        return frame
    
    def detectShapeAndColoredObjects(self, frame : np.ndarray) -> np.ndarray:
        
        for shapeAndColoredObject in self.shapeAndColoredObjects:
            
            # if (shapeAndColoredObject.targetImage.shape[0] > frame.shape[0] or
            #     shapeAndColoredObject.targetImage.shape[1] > frame.shape[1]):
            #     print(f"(!?)-- Skipping {shapeAndColoredObject.name} - target image is larger than frame.")
            #     continue  # Skip this object if target image is too large
            
            
            # Apply template matching

            result = cv2.matchTemplate(shapeAndColoredObject.targetImage, frame, cv2.TM_CCOEFF_NORMED)



            # Define a threshold for matching

            threshold = shapeAndColoredObject.threshold

            locations = np.where(result >= threshold)

            if(len(locations) > 1):

                found : bool = False 

                for pt in zip(*locations[::-1]):

                    top_left = pt

                    bottom_right = (pt[0] + shapeAndColoredObject.targetImage.shape[1], pt[1] + shapeAndColoredObject.targetImage.shape[0])

                    frame = cv2.rectangle(frame, top_left, bottom_right, (shapeAndColoredObject.color), 2)

                    found = True
                    
                    x, y = top_left
                    w = shapeAndColoredObject.targetImage.shape[1]
                    h = shapeAndColoredObject.targetImage.shape[0]


                    shapeAndColoredObject.callback(x, y, w, h)
                    
                    
    def detectAprilTags(self, frame : np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        corners, ids, rejected = detector.detectMarkers(gray)

        if ids is not None:
            for i, corner in enumerate(corners):
                # Draw the bounding box around the marker
                frame = aruco.drawDetectedMarkers(frame, corners, ids)
                
                # Extract the bounding box points (top-left, top-right, bottom-right, bottom-left)
                corner = corner[0]
                top_left = corner[0]
                bottom_right = corner[2]
                
                # Calculate x, y, w, h
                x, y = int(top_left[0]), int(top_left[1])
                w = int(bottom_right[0] - top_left[0])
                h = int(bottom_right[1] - top_left[1])
            
                # Loop through the AprilTags to find the matching ID
                for aprilTag in self.aprilTags:
                    if aprilTag.id == ids[i][0]:  # Compare with the current detected ID
                        aprilTag.callback(x, y, w, h)
                        break
                # cv2.putText(frame, f"ID: {ids[i][0]}", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        
        return frame
        

    
    def addHarrCascade(self, harr : HaarcascadeObject) -> None:
        self.harrCascades.append(harr)
    
    def addColoredObject(self, coloredObject : ColoredObject) -> None:
        self.coloredObjects.append(coloredObject)
    
    def addShapeAndColoredObject(self, shapeAndColoredObject : ShapeAndColoredObject) -> None:
        self.shapeAndColoredObjects.append(shapeAndColoredObject)
    
    def addAprilTag(self, aprilTag : AprilTag) -> None:
        self.aprilTags.append(aprilTag)
    
    def analyze(self) -> None:
        ret : bool
        frameRAW : np.ndarray
        detectedFrame : np.ndarray
        
        ret, frameRAW = cap.read()

        if not ret or frameRAW.size == 0:
            print("(!)-- Failed to capture image.")
            cap.release()
            cv2.destroyAllWindows()
            exit(1)

        
        detectedFrame = frameRAW.copy()
       
        # detect
        
        detectedFrame = self.detectShapeAndColoredObjects(frameRAW)
        detectedFrame = self.detectHarrCascades(frameRAW)
        detectedFrame = self.detectColoredObjects(frameRAW)
        
        detectedFrame = self.detectAprilTags(frameRAW)
        
        cv2.imshow("Raw cam feed", frameRAW)
        cv2.imshow("Main frame", detectedFrame)
        
        

cap : cv2.VideoCapture = cv2.VideoCapture(0)

cam : Camera = Camera()
