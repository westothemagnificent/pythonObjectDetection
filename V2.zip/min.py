from cam import *

# This code should be veiwed after reading the main.py comments!

cam.addAprilTag(
    AprilTag(
        "cool marker",
        12,
        (255,60,80),
        lambda x,y,w,h: print(f"I see a very cool april tag with ID: 12 at: {x}, {y} and is {cam.getDistance(w, 1, 30.5, 138)}cm far away from me!"),
    )
)

if(not cap.isOpened()):
    exit(1)

setDrawGUI(True)

while True:
    cam.analyze()
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# yes this is it.
# and for all you non formaters!

# from cam import *
# cam.addAprilTag(AprilTag("cool marker",12,(255,60,80),lambda x,y,w,h: print(f"I see a very cool april tag with ID: 12 at: {x}, {y} and is {cam.getDistance(w, 1, 30.5, 138)}cm far away from me!")))
# if(not cap.isOpened()):exit(1)
# setDrawGUI(True)
# while True:
#     cam.analyze()
#     if cv2.waitKey(1) & 0xFF == ord('q'):break
