from PIL import Image
import numpy as np
import sys


def add_noise_to_transparent_area(image_path, output_path):
    # Open the image
    img = Image.open(image_path).convert("RGBA")
    
    # Convert the image to a numpy array
    img_array = np.array(img)
    
    # Create a random noise pattern for the transparent areas
    noise = np.random.randint(0, 256, size=img_array.shape, dtype=np.uint8)
    
    # Identify the transparent areas (where alpha == 0)
    alpha_channel = img_array[:, :, 3]
    transparent_mask = alpha_channel == 0
    
    # Replace transparent areas with noise (only in the RGB channels, not the alpha)
    img_array[transparent_mask, :3] = noise[transparent_mask, :3]
    
    # Set the alpha channel of the noisy pixels to 254 (instead of 255)
    img_array[transparent_mask, 3] = 254
    
    # Calculate the percentage of noise pixels
    total_pixels = img_array.shape[0] * img_array.shape[1]
    noise_pixels = np.sum(transparent_mask)
    noise_percentage = (noise_pixels / (total_pixels))
    
    # Print the percentage of the image filled with noise
    print(f"Percentage of image filled with noise: {noise_percentage:.2f}")
    
    # Convert the modified numpy array back to an image
    new_img = Image.fromarray(img_array)
    
    # Save the output image
    new_img.save(output_path, format="PNG")


# Example usage
image_path = sys.argv[1]  # Path to the input image
output_path = sys.argv[2]    # Path to save the output image
add_noise_to_transparent_area(image_path, output_path)
