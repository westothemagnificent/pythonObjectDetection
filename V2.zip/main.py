from cam import *
import os
from pynput import keyboard

# # Add HaarCascade
# cam.addHarrCascade(
#     HaarcascadeObject(
#         "face",
#         cv2.data.haarcascades + "haarcascade_frontalface_default.xml",
#         (50, 120, 255),
#         lambda x, y, w, h: print(f"I see a face at: {(x, y, w, h)}"),
#     )
# )

# # Detect blue in (BGR)
# cam.addColoredObject(
#     ColoredObject(
#         "blue",
#         (80, 0, 0),
#         (200, 100, 100),
#         200,
#         (255, 100, 100),
#         lambda x, y, w, h, c: print(f"I see a blue object at: {(x, y, w, h)}"),
#     )
# )

# add april tag (you do not need to detect april tag just needed to have a callback)

cam.addAprilTag(
    AprilTag(
        "cool marker",
        12,
        (255,60,80),
                                                                                         # NOTE: These values are for a specific setup. Replace them with measurements and configurations tailored to your camera and AprilTag.
                                                                                         # if you want to use this function FIRST get an april tag then replace this code lambda with: print(f"w: {w}")
                                                                                         # then hold your april tag (correctly) at any distance you like (The closer the better) after doing so write down the distance AND the width that was printed out
                                                                                         # after do this: cam.getDistance(w, <Your tag's REAL LIFE size>, <How far you held your tag>, <Your tag's PIXEL size>, <The size how your tag HELD at the distance IN PIXELS>)
                                                                                         # Now you can get the distance of your tag
        lambda x,y,w,h: print(f"I see a very cool april tag with ID: 12 at: {x}, {y} and is {cam.getDistance(w, 1, 30.5, 138)}cm far away from me!"),
    )
)

# add an object
# NOTE that the addShapeAndColoredObject is NOT done yet
# ALSO NOTE that these photos are not here for public builds


# simple photo taker

def saveImageWithoutOverwriting(image, baseFilename):

    filename, ext = os.path.splitext(baseFilename)
    if not ext:
        ext = ".png"  # Default extension if none is provided
    
    counter = 1
    newFilename = baseFilename
    
    while os.path.exists(newFilename):
        newFilename = f"{filename}{counter}{ext}"
        counter += 1
    
    cv2.imwrite(newFilename, image)
    return newFilename


# TESTING STUFF
def tickTakePhoto(key: keyboard.KeyCode):
    ret, frame = cap.read()

    if key.vk == 80:  # If 'P' key is pressed
        
        roi_size = 300
        width, height = 600, 600
        x = (width - roi_size) // 2
        y = (height - roi_size) // 2

        frame = frame[y:y + roi_size, x:x + roi_size]


        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2BGRA)

        lower_black = np.array([0, 0, 0, 255], dtype=np.uint8)
        upper_black = np.array([60, 60, 60, 255], dtype=np.uint8)

        # Threshold to create a mask for the black background
        mask = cv2.inRange(frame, lower_black, upper_black)

        # Replace black pixels with transparency (zero alpha channel)
        frame[:, :, 3] = np.where(mask == 255, 0, frame[:, :, 3])  # Set alpha to 0 for black pixels


                
        
        name = saveImageWithoutOverwriting(frame, "object.png")
        os.system(f"python noise.py {name} {name.split('.png')[0]}Noise.png")

        print("(*)-- photo taken")


if not cap.isOpened():
    print("(!!)-- Could not open camera.")
    exit(1)
else:
    setDrawGUI(True)
    
    print("starting...")
    
    listener = keyboard.Listener(on_release=tickTakePhoto)
    listener.start()
    
    # load objects pic NOTE: NOT IN PUBLIC BUILD
    # for i in range(28):
    #     name = ""
    #     if(i != 0):
    #         name = f"object{i}.png"
    #     else:
    #         name = "object.png"
    #     cam.addShapeAndColoredObject(
    #         ShapeAndColoredObject(
    #             "cool object",
    #             name,
    #             0.71,
    #             (50,200,40),
    #             lambda x,y,w,h: print(f"I SEE THE OBJECT AT: {x}, {y}"),
    #         )
    #     )
    #     print(name)


    while True:
        # tick the cam to find objects added above
        frameRAW, frame = cam.analyze()
        
        roi_size = 300
        width, height = 600, 600
        x = (width - roi_size) // 2  # Center the ROI horizontally
        y = (height - roi_size) // 2  # Center the ROI vertically

        # Draw the rectangle (ROI) in the center
        cv2.rectangle(frame, (x, y), (x + roi_size, y + roi_size), (0, 255, 0), 10)  # Green rectangle with thickness 2

        cv2.imshow("ROI", frame)
                
        # see if "q" pressed if so exit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break


cap.release()
cv2.destroyAllWindows()